# Server

Node.js + Express + SQLite + Socket.IO backend for the V21-base-plus build.
